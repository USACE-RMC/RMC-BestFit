ARR-FLIKE Examples:

-This example follows the methodology provided by Australian Rainfall and Runoff using the Flike software, as included in the RMC-BestFit Verification Report for version 1.0.

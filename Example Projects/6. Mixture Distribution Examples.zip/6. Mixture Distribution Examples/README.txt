Mixture Distributions:

-This example demonstrates fitting a mixture of distributions, including a 2-component Normal mixture, a 3-component Normal mixture, and a zero-inflated 2-component Normal mixture. The datasets used are synthetic with known properties for controlled analysis. 
Composite Distribution Examples:

-This example demonstrates various scenarios, including competing failure modes, different flood types, mixtures of flood types, and model averaging. Synthetic datasets with known properties are used to allow for controlled analysis.
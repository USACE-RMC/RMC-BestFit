Blakely Mountain Dam Example:

-This example follows the workflow provided in the Quick Start User Guide for version 1.0.
-The dataset includes systematic data, historical data dating back to 1870, and paleoflood information extending back 5,000 years.
-The skew prior is set using regional skew information from the USGS.
-Quantile priors are established based on stochastic rainfall-runoff data.

Viglione et al. 2013 Example:

-This example follows the methodology outlined by Viglione et al. (2013) and is also included in the RMC-BestFit Verification Report for version 1.0.
-It includes a comparison with Evdbayes using 3 quantile priors and utilizes the Kamp at Zwettl dataset from 1951–2001, as detailed in Viglione et al. (2013).
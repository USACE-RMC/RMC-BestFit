Measurement Errors:

-This example demonstrates how to incorporate measurement errors (or prediction errors) derived from a MOVE.3 analysis. 
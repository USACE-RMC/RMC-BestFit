Bulletin 17C Examples:

-This example follows the approach outlined in Bulletin 17C, utilizing the Expected Moments Algorithm (EMA). The flow data is imported directly from the USGS, using the most recent available data.
-Additionally, daily USGS data is imported for testing and demonstration purposes.
-For a comparison using the data from B17C (2018), refer to the RMC-BestFit Verification Report for version 1.0.

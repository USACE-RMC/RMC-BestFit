Brays Bayou, Texas:

- This example demonstrates a nonstationary flood frequency analysis (NSFFA) for a gage in Texas that exhibits an upward trend.

Cherry Creek Dam:

-This example performs an NSFFA on data showing a slight downward trend; however, it is unclear if the NSFFA approach improves upon a stationary analysis. Both AIC and BIC criteria indicate a preference for the stationary fit.

O.C. Fisher – ANCOLD:

-This example follows the NSFFA approach outlined in the ANCOLD paper.
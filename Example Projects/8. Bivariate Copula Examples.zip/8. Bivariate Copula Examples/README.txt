Bivariate Distribution Examples:

This example demonstrates fitting bivariate copulas for various copula types. Each dataset is synthetic, with marginal normal distributions and differing copula dependencies. 